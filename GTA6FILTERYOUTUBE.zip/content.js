const KEYWORDS = [
  'gta 6', 'gta vi', 'gta6', 'gta-6',
  'grand theft auto 6', 'grand theft auto vi',
  'гта 6', 'гта vi', 'гта6', 'гта-6',
];

const filteredVideos = new Map();
const dismissedUrls = new Set();
const descCache = new Map();
const descQueue = [];
let descProcessing = false;
let descEnabled = true;
let filterMode = 'blur'; // 'hide' | 'blur'

const FILTER_CLASSES = ['gta6-hidden', 'gta6-blurred'];
const MAX_DESC_FETCH = 200;
const DESC_DELAY_MS = 700;

// ---------- настройки ----------
chrome.storage.sync.get(
  { checkDescription: true, filterMode: 'blur' },
  (res) => {
    const prevMode = filterMode;
    descEnabled = res.checkDescription;
    filterMode = res.filterMode;
    if (prevMode !== filterMode) reapplyMode();
    runFilter();
  }
);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'sync') return;
  if ('checkDescription' in changes) descEnabled = changes.checkDescription.newValue;
  if ('filterMode' in changes) {
    filterMode = changes.filterMode.newValue;
    reapplyMode();
  }
});

function reapplyMode() {
  document.querySelectorAll(FILTER_CLASSES.map(c => '.' + c).join(','))
    .forEach(el => {
      el.classList.remove(...FILTER_CLASSES);
      delete el.dataset.gta6Filtered;
    });
  runFilter();
}

// ---------- утилиты ----------
function matchesKeywords(text) {
  if (!text) return false;
  const lower = text.toLowerCase();
  return KEYWORDS.some(k => lower.includes(k));
}

function normalizeUrl(url) {
  if (!url) return '';
  try {
    const u = new URL(url, location.origin);
    if (u.pathname === '/watch') {
      const v = u.searchParams.get('v');
      return v ? `${location.origin}/watch?v=${v}` : '';
    }
    if (u.pathname.startsWith('/shorts/')) return `${location.origin}${u.pathname}`;
    return '';
  } catch (e) { return ''; }
}

function currentVideoUrl() { return normalizeUrl(location.href); }

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function isFiltered(el) {
  return FILTER_CLASSES.some(c => el.classList.contains(c));
}

function applyFilterClass(video) {
  video.classList.remove(...FILTER_CLASSES);
  video.classList.add(filterMode === 'blur' ? 'gta6-blurred' : 'gta6-hidden');
}

// ---------- детект игры ----------
function getGameAttribute(root) {
  let el = root.querySelector('.ytVideoAttributeViewModelTitle');
  if (el && el.textContent.trim()) return el.textContent.trim();
  el = root.querySelector('[class*="VideoAttribute"] [class*="Title"]');
  if (el && el.textContent.trim()) return el.textContent.trim();
  return '';
}

// ---------- карточки ----------
function extractUrl(video) {
  const link = video.querySelector(
    'a#thumbnail, a#video-title-link, a#video-title, a[href*="/watch?v="], a[href*="/shorts/"]'
  );
  return link && link.href ? normalizeUrl(link.href) : '';
}

function extractTitle(video) {
  const el = video.querySelector('#video-title, #video-title-link, h3');
  return el ? (el.textContent || el.getAttribute('title') || '').trim() : '';
}

function extractSnippet(video) {
  const selectors = ['#description-text', '#description', '.metadata-snippet-text'];
  for (const sel of selectors) {
    const el = video.querySelector(sel);
    if (el && el.textContent) return el.textContent.trim();
  }
  return '';
}

function markFiltered(video, title, url, source) {
  if (url && dismissedUrls.has(url)) return;
  applyFilterClass(video);
  if (url && !filteredVideos.has(url)) {
    filteredVideos.set(url, { title, source });
    updateBadge();
  }
}

function hideByUrl(url, source) {
  const sel = 'ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, ytd-reel-item-renderer';
  document.querySelectorAll(sel).forEach(video => {
    if (isFiltered(video)) return;
    if (extractUrl(video) === url) {
      markFiltered(video, extractTitle(video), url, source || 'description');
    }
  });
}

function updateBadge() {
  chrome.runtime.sendMessage({
    action: 'setBadge',
    text: filteredVideos.size ? String(filteredVideos.size) : ''
  });
}

// ---------- описание ----------
function extractDescriptionFromHtml(html) {
  let m = html.match(/"shortDescription":"((?:[^"\\]|\\.)*)"/);
  if (m) { try { return JSON.parse('"' + m[1] + '"'); } catch (e) {} }
  m = html.match(/"attributedDescription":\{"content":"((?:[^"\\]|\\.)*)"/);
  if (m) { try { return JSON.parse('"' + m[1] + '"'); } catch (e) {} }
  return null;
}

async function fetchDescription(url) {
  try {
    const res = await fetch(url, { credentials: 'same-origin' });
    if (!res.ok) return null;
    return extractDescriptionFromHtml(await res.text());
  } catch (e) { return null; }
}

function queueDescFetch(url) {
  if (!descEnabled || !url) return;
  if (descCache.has(url) || descQueue.includes(url)) return;
  if (descCache.size >= MAX_DESC_FETCH) return;
  if (descQueue.length > 30) return;
  descQueue.push(url);
  processDescQueue();
}

async function processDescQueue() {
  if (descProcessing) return;
  descProcessing = true;
  while (descQueue.length > 0) {
    const url = descQueue.shift();
    if (descCache.has(url)) continue;
    descCache.set(url, true);
    const desc = await fetchDescription(url);
    descCache.set(url, desc || false);
    if (desc && matchesKeywords(desc)) hideByUrl(url, 'description');
    await new Promise(r => setTimeout(r, DESC_DELAY_MS));
  }
  descProcessing = false;
}

// ---------- карточки: проход ----------
function filterCards() {
  const sel = 'ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, ytd-reel-item-renderer';

  document.querySelectorAll(sel).forEach(video => {
    if (video.dataset.gta6Filtered) return;

    const title = extractTitle(video);
    const url = extractUrl(video);
    const snippet = extractSnippet(video);
    const gameAttr = getGameAttribute(video);

    if (matchesKeywords(gameAttr)) markFiltered(video, title, url, 'attribute');
    else if (matchesKeywords(title)) markFiltered(video, title, url, 'title');
    else if (matchesKeywords(snippet)) markFiltered(video, title, url, 'description');
    else if (url) queueDescFetch(url);

    video.dataset.gta6Filtered = 'true';
  });
}

// ---------- страница просмотра ----------
function getWatchOverlay() { return document.getElementById('gta6-watch-overlay'); }
function getPlayerContainer() {
  return document.querySelector('#player-container, ytd-player, #player');
}

function removeWatchOverlay() {
  const ov = getWatchOverlay();
  if (ov) ov.remove();
  const player = getPlayerContainer();
  if (player) player.style.display = '';
}

function checkWatchPage() {
  // В режиме блюра страницу просмотра не блокируем — играет как обычно
  if (filterMode !== 'hide') { removeWatchOverlay(); return; }

  const url = currentVideoUrl();
  if (!url || dismissedUrls.has(url)) { removeWatchOverlay(); return; }

  const player = getPlayerContainer();
  if (!player) return;

  const isGta6 = matchesKeywords(getGameAttribute(document));
  const existingOv = getWatchOverlay();

  if (!isGta6) {
    if (existingOv && existingOv.dataset.url === url && filteredVideos.has(url)) return;
    removeWatchOverlay();
    return;
  }

  if (existingOv && existingOv.dataset.url === url) return;
  removeWatchOverlay();

  const title = (document.querySelector(
    'h1.ytd-watch-metadata, ytd-watch-metadata h1, h1.title'
  )?.textContent?.trim()) || document.title.replace(' - YouTube', '').trim();

  filteredVideos.set(url, { title, source: 'attribute' });
  updateBadge();

  const ov = document.createElement('div');
  ov.id = 'gta6-watch-overlay';
  ov.dataset.url = url;
  ov.innerHTML = `
    <div class="gta6-overlay-inner">
      <div class="gta6-overlay-emoji">🚫</div>
      <div class="gta6-overlay-title">Видео о GTA 6 скрыто</div>
      <div class="gta6-overlay-sub">${escapeHtml(title)} — отфильтровано расширением GTA 6 Filter.</div>
      <div class="gta6-overlay-actions">
        <button id="gta6-show-anyway" type="button">Показать всё равно</button>
        <button id="gta6-hide-forever" type="button">Больше не показывать</button>
      </div>
    </div>
  `;

  player.parentNode.insertBefore(ov, player.nextSibling);
  player.style.display = 'none';

  document.getElementById('gta6-show-anyway').addEventListener('click', () => {
    dismissedUrls.add(url);
    removeWatchOverlay();
  });
  document.getElementById('gta6-hide-forever').addEventListener('click', () => {
    dismissedUrls.add(url);
    removeWatchOverlay();
    location.href = '/';
  });
}

// ---------- запуск ----------
function runFilter() {
  filterCards();
  checkWatchPage();
}

// SPA-переходы
window.addEventListener('yt-navigate-start', removeWatchOverlay);
window.addEventListener('yt-navigate-finish', () => setTimeout(runFilter, 300));

let lastUrl = location.href;
setInterval(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    setTimeout(runFilter, 300);
  }
  runFilter();
}, 2000);

const observer = new MutationObserver(() => runFilter());
observer.observe(document.body, { childList: true, subtree: true });

// ---------- обмен с попапом ----------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getFiltered') {
    const videos = Array.from(filteredVideos.entries()).map(([url, info]) => ({
      url, title: info.title, source: info.source,
    }));
    sendResponse({ videos, descEnabled, filterMode });
  } else if (message.action === 'resetFiltered') {
    filteredVideos.clear();
    dismissedUrls.clear();
    document.querySelectorAll(FILTER_CLASSES.map(c => '.' + c).join(','))
      .forEach(el => {
        el.classList.remove(...FILTER_CLASSES);
        delete el.dataset.gta6Filtered;
      });
    removeWatchOverlay();
    descCache.clear();
    descQueue.length = 0;
    updateBadge();
    sendResponse({ ok: true });
  } else if (message.action === 'showUrl') {
    dismissedUrls.add(message.url);
    filteredVideos.delete(message.url);
    document.querySelectorAll(FILTER_CLASSES.map(c => '.' + c).join(','))
      .forEach(el => {
        if (extractUrl(el) === message.url) {
          el.classList.remove(...FILTER_CLASSES);
          delete el.dataset.gta6Filtered;
        }
      });
    if (currentVideoUrl() === message.url) removeWatchOverlay();
    updateBadge();
    sendResponse({ ok: true });
  }
  return true;
});