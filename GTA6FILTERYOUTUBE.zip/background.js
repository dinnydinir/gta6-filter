chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.action === 'setBadge' && sender.tab && sender.tab.id) {
    chrome.action.setBadgeText({
      tabId: sender.tab.id,
      text: msg.text || ''
    });
    chrome.action.setBadgeBackgroundColor({
      tabId: sender.tab.id,
      color: '#c00'
    });
  }
});