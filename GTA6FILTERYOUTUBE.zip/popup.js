const listEl = document.getElementById('list');
const countEl = document.getElementById('count');
const statusEl = document.getElementById('status');
const chkDesc = document.getElementById('chkDesc');
const btnReset = document.getElementById('btnReset');
const modeBlur = document.getElementById('modeBlur');
const modeHide = document.getElementById('modeHide');

let currentTabId = null;
let pollTimer = null;

// ---------- настройки ----------
chrome.storage.sync.get(
  { checkDescription: true, filterMode: 'blur' },
  (res) => {
    chkDesc.checked = res.checkDescription;
    if (res.filterMode === 'hide') modeHide.checked = true;
    else modeBlur.checked = true;
  }
);

chkDesc.addEventListener('change', () => {
  chrome.storage.sync.set({ checkDescription: chkDesc.checked });
});

[modeBlur, modeHide].forEach(r => r.addEventListener('change', () => {
  if (r.checked) chrome.storage.sync.set({ filterMode: r.value });
}));

// ---------- инициализация ----------
async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.includes('youtube.com')) {
    statusEl.textContent = 'Откройте YouTube, чтобы увидеть список';
    return;
  }
  currentTabId = tab.id;
  statusEl.textContent = 'Активно';
  refresh();
  pollTimer = setInterval(refresh, 1000);
}

async function refresh() {
  if (currentTabId === null) return;
  try {
    const response = await chrome.tabs.sendMessage(currentTabId, { action: 'getFiltered' });
    render(response ? response.videos : []);
  } catch (e) {
    statusEl.textContent = 'Перезагрузите страницу YouTube';
  }
}

const SOURCE_LABEL = { attribute: 'игра', title: 'название', description: 'описание' };

function render(videos) {
  countEl.textContent = videos.length;
  listEl.innerHTML = '';

  if (!videos.length) {
    const li = document.createElement('li');
    li.className = 'empty';
    li.textContent = 'Пока нет скрытых видео';
    listEl.appendChild(li);
    return;
  }

  videos.forEach(v => {
    const li = document.createElement('li');

    const badge = document.createElement('span');
    badge.className = 'badge' + (v.source === 'description' ? ' desc' : v.source === 'attribute' ? ' attr' : '');
    badge.textContent = SOURCE_LABEL[v.source] || 'название';
    li.appendChild(badge);

    const a = document.createElement('a');
    a.href = v.url || '#';
    a.target = '_blank';
    a.rel = 'noopener';
    a.textContent = v.title || '(без названия)';
    li.appendChild(a);

    const showBtn = document.createElement('button');
    showBtn.textContent = '👁';
    showBtn.title = 'Показать это видео';
    showBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      try {
        await chrome.tabs.sendMessage(currentTabId, { action: 'showUrl', url: v.url });
        refresh();
      } catch (err) {}
    });
    li.appendChild(showBtn);

    listEl.appendChild(li);
  });
}

btnReset.addEventListener('click', async () => {
  if (currentTabId === null) return;
  try {
    await chrome.tabs.sendMessage(currentTabId, { action: 'resetFiltered' });
    refresh();
  } catch (e) {}
});

window.addEventListener('unload', () => {
  if (pollTimer) clearInterval(pollTimer);
});

init();